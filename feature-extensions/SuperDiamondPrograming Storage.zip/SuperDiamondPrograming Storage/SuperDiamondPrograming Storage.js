if(typeof SuperDiamondPrograming !== "undefined" && typeof SuperDiamondPrograming !== "undefined") {
 SuperDiamondPrograming.Functions.Storage.installed = true
 SuperDiamondPrograming.Functions.Storage.setItems(items, value) = function() { chrome.storage.local.set(items, value) }
 SuperDiamondPrograming.Functions.Storage.removeItems(items) = function() { chrome.storage.local.remove(items) }
 SuperDiamondPrograming.Functions.Storage.get(item) = function() { chrome.storage.local.get(item) }
 SuperDiamondPrograming.Functions.Storage.byteUsage() = function() { chrome.storage.local.getBytesInUse(null) }
 SuperDiamondPrograming.Functions.Storage.chromeExtensionAPI = chrome.storage
}