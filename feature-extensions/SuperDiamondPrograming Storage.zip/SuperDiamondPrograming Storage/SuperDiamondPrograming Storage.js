if(typeof SuperDiamondPrograming !== "undefined" && typeof SuperDiamondPrograming !== "undefined") {
 SuperDiamondPrograming.Functions.Storage.installed = true
 SuperDiamondPrograming.Functions.Storage.setItem(item, value) = function() { chrome.storage.local.set(item, value) }
 SuperDiamondPrograming.Functions.Storage.removeItem(item) = function() { chrome.storage.local.remove(item) }
 SuperDiamondPrograming.Functions.Storage.get(item) = function() { chrome.storage.local.get(item) }
 SuperDiamondPrograming.Functions.Storage.byteUsage() = function() { chrome.storage.local.getBytesInUse(null) }
 SuperDiamondPrograming.Functions.Storage.chromeExtensionAPI = chrome.storage
}