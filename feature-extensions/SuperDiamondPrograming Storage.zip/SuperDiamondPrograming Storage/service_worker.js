chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.sender === "SuperDiamondPrograming" && message.destination === "SuperDiamondPrograming Storage API") {
        executeDynamicServiceWorker(message.request, (result) => {
            if (result !== null) {
                chrome.runtime.sendMessage({
                    sender: "SuperDiamondPrograming Storage API",
                    destination: "SuperDiamondPrograming",
                    successful: true,
                    result: result
                });
            } else {
                chrome.runtime.sendMessage({
                    sender: "SuperDiamondPrograming Storage API",
                    destination: "SuperDiamondPrograming",
                    successful: false,
                    result: "ERROR"
                });
            }
        });
    }
});

function executeDynamicServiceWorker(scriptContent, callback) {
    const blob = new Blob([scriptContent], { type: 'application/javascript' });
    const blobURL = URL.createObjectURL(blob);

    navigator.serviceWorker.register(blobURL, { type: 'module' }) // Added type: 'module'
        .then(registration => {
            const channel = new MessageChannel();
            navigator.serviceWorker.controller.postMessage({ action: 'executeCode' }, [channel.port2]);
            channel.port1.onmessage = (event) => {
                const result = event.data.result;
                callback(result);
                registration.unregister().then(() => {
                    console.log("SuperDiamondPrograming Storage API: Successfully Executed ", scriptContent);
                });
            };
        })
        .catch(error => {
            console.error("SuperDiamondPrograming Storage API: Failed to execute ", scriptContent, " by Registering Dynamic Service Worker. ERROR: ", error);
            callback(null);
        });
}

self.addEventListener('message', event => {
    if (event.data.action === 'executeCode') {
        const result = someFunction();
        const channel = new MessageChannel();
        event.source.postMessage({ action: 'codeExecuted', result: result }, [channel.port2]);
    }
});

function someFunction() {
    return "Hello from the service worker!";
}