window.onload = function() {
  try {
     if (typeof navigator.serviceWorker !== 'undefined') {
        navigator.serviceWorker.addEventListener('message', event => {
           if (event.data.sender === "SuperDiamondPrograming Storage API" && event.data.destination === "SuperDiamondPrograming") {
            document.getElementById("SuperDiamondProgramingStorageAPILastResponse").innerHTML = JSON.stringify({ successful: event.data.successful, result: event.data.result, data: event.data });
           }
        });
        SuperDiamondProgramingStorageAPI.installed = true;
        SuperDiamondProgramingStorageAPI.byteUsage = function() { 
           navigator.serviceWorker.controller.postMessage({ destination: "SuperDiamondPrograming Storage API", sender: "SuperDiamondPrograming", request: "chrome.storage.getBytesInUse(null)" });
        };
        SuperDiamondProgramingStorageAPI.chromeExtensionAPIRequest = function(request) { 
           navigator.serviceWorker.controller.postMessage({ destination: "SuperDiamondPrograming Storage API", sender: "SuperDiamondPrograming", request: "chrome.storage." + request });
        };
        SuperDiamondProgramingStorageAPI.LastRequest = function() { 
          return document.getElementById("SuperDiamondProgramingStorageAPILastResponse").innerHTML;
        };
        var SuperDiamondProgramingStorageAPIE = document.createElement("SuperDiamondProgramingData")
        var SuperDiamondProgramingStorageAPILastResponse = document.createElement("SuperDiamondProgramingData")
        SuperDiamondProgramingStorageAPIE.style.display = "none"
        SuperDiamondProgramingStorageAPIE.id = "SuperDiamondProgramingStorageAPI"
        SuperDiamondProgramingStorageAPIE.innerHTML = JSON.stringify(SuperDiamondProgramingStorageAPI)
        document.body.appendChild(SuperDiamondProgramingStorageAPIE)
        SuperDiamondProgramingStorageAPILastResponse.style.display = "none"
        SuperDiamondProgramingStorageAPILastResponse.id = "SuperDiamondProgramingStorageAPILastResponse"
        document.body.appendChild(SuperDiamondProgramingStorageAPILastResponse)
        console.info("SuperDiamondPrograming Storage API has started up")
        const event = new Event("SuperDiamondPrograming Storage API Startup")
        window.dispatchEvent(event);
     }
  } catch (err) {
    console.error("SuperDiamondPrograming Storage API Startup Error: " + err);
  }
};